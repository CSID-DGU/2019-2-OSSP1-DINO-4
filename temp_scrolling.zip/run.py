import pygame
from game import *

if __name__=="__main__":
    g=Game()
    g.main()